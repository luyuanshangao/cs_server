# ethereum-rpc

Ethereum (geth) RPC client

## Prerequisites

* PHP >= 7.1
* [furqansiddiqui/http-client](https://github.com/furqansiddiqui/http-client) >= v0.3.0

## Installation

`composer require furqansiddiqui/ethereum-rpc`